interface A 
{
    public static display1();

}
interface B
{
    public static display2();
}
interface C extends A,B
{
    public static 
}