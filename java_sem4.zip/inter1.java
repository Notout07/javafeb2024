interface x
{
    int x = 5;
}
class varIn implements x
{
    public static void getx()
    {
        System.out.println("X = " +x);
    }
}
public class inter1 
{
    public static void main(String args[])
    {
        varIn v = new varIn();
        v.getx();
    }
}