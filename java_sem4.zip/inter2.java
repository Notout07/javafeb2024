interface A 
{
    void display1();
    
}
interface B
{
    void display2();
    
}
interface C extends A,B
{
    void display3(); 
    
}
class D implements A,B,C
{
    public void display1()
    {
        System.out.println("Interface A");
    }
    public void display2()
    {
        System.out.println("Interface B");
    }
    public void display3()
    {
        System.out.println("Interface C");
    }
}
class inter2
{
    public static void main(String args[])
    {
        D obj = new D();
        obj.display1();
        obj.display2();
        obj.display3();
    }
}