class maths
{
    public static void main(String args[])
    {
        int  n1,n2,ans_add,ans_sub,ans_mul,ans_div;
        n1 = 20;
        n2 = 2;
        ans_add = n1 + n2;
        ans_sub = n1 - n2;
        ans_mul = n1 * n2;
        ans_div = n1 / n2;
        System.out.println("Addition is "+ ans_add);
        System.out.println("Subtraction is "+ ans_sub);
        System.out.println("multiplication is "+ ans_mul);
        System.out.println("division is "+ ans_div);
    }
}