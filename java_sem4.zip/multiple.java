interface A 
{
    public void display();
}
interface B
{
    public void display1();
}
interface C extends A,B
{
    public void display2();
}
class D implements C  
{
    public void display()
    {
        System.out.println("this is one:");
    }
    public void display1()
    {
        System.out.println("this is two:");
    }
    public void display2()
    {
        System.out.println("this is three:");
    }
    public void display3()
    {
        System.out.println("this is four:");
    }
}
class multiple
{
    public static void main(String args[])
    {
        System.out.println("hello from main class");
        D f = new D();
        f.display();
        f.display1();
        f.display2();
        f.display3();
    }
}