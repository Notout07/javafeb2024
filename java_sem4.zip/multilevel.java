class one
{
    static void display()
    {
        System.out.println("This is an one");
    }
}
class two extends one
{
    static void display1()
    {
        System.out.println("This is Two");
    }
}
class three extends two
{
    static void display2()
    {
        System.out.println("This is three");
    }
}
class multilevel
{
    public static void main(String args[])
    {
        three obj=new three();
        obj.display();
        obj.display1();
        obj.display2();
    }
}      