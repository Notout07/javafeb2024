abstract class shape
{
    abstract void area();
}
class Triangle extends shape
{
    double b=50, h=20;
    void area()
    {
        double area1;
        area1 = (b * h)/2;
        System.out.println("Area of Triangle is: " + area1);
    }
}
class Rectangle extends shape
{
    double l=20, b=30;
    void area()
    {
        double area2;
        area2 = l*b;
        System.out.println("Area of Rectangle is: " + area2);
    }
}
public class pract8
{
    public static void main(String args[])
    {
        Triangle t = new Triangle();
        Rectangle r = new Rectangle();
        t.area();
        r.area();
    }
}
