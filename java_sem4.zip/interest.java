class interest
{
    public static void main(String args[])
    {
        double p,r,n,ans;
        p = 6000;
        r =  5;
        n = 12;
        ans = (p * r * n)/100;
        System.out.println("Interest is "+ ans);
    }
}