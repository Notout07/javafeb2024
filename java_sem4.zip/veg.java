abstract class vegetable
{
    public String color;
}
class Potato extends vegetable
{
    public String toString()
    {
        color = "Brown -skinned Color";
        return "potato= "+ color;
    }
}
class Brinjal extends vegetable
{
    public String toString()
    {
        color = "Purple Color";
        return "brinjal="+ color;
    }
}
class Tomato extends vegetable
{
    public String toString()
    {
        color = "Red Color";
        return "tomato="+ color;
    }
}
class veg
{
    public static void main(String args[])
    {
        Potato p = new Potato();
        Brinjal b = new Brinjal();
        Tomato t = new Tomato();
        System.out.println(p);
        System.out.println(b);
        System.out.println(t);
    }
}