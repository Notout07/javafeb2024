class for_each
{
    public static void main(String args[])
    {
        int a[] = {1,2,3,4,5,6};
        for(int i:a)
        {
            System.out.println(i);
        }
    }
}