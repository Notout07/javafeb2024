class one
{
    static void display()
    {
        System.out.println("This is one:");
    }
}
class two extends one
{
    static void display1()
    {
        System.out.println("This is two:");
    }
}
class three extends one
{
    static void display2()
    {
        System.out.println("This is three:");
    }
}
class hierarchy
{
    public static void main(String args[])
    {
        two obj = new two();
        obj.display();
        obj.display1();
        three obj1 = new three();
        obj1.display2();
    }
}