 import java.util.Scanner;
 interface Exam
 {
    boolean Pass(int mark);
 }
 interface Classify
 {
    String Division(int avg);
 }
 class Result implements Exam,Classify
 {
    public boolean Pass(int marks)
    {
        if(marks>35)
            return true;
        else 
            return false;
    }
    public String Division(int avg)
    {
        if(avg >=60)
            return "First";
        else if (avg >=50)
            return "Second";
        else
            return "No division";
    }
 }
    public class MyResult1
    {
        public static void main(String args[])
        {
            Result obj = new Result();
            Scanner sc = new Scanner(System.in);
            boolean pass;
            String div1;
            int marks=50,avg=60;

            pass = obj.Pass(marks);
            div1 = obj.Division(avg);
            System.out.println("Student marks is "+marks); 
            System.out.println("Student avg is "+avg);
            System.out.println("Student class is "+div1);

            System.out.println("Enter Marks : ");
            marks=sc.nextInt();
            System.out.println("Enter Average : ");
            avg=sc.nextInt();
            
            if(obj.Pass(marks))
            System.out.println("Student is pass and class is" +obj.Division(avg));
            else
            System.out.println("Student is fail");
        }
    }