public  class company
{
	public static void main(String args[])
	{
		String c[]={"Tinkal","Reena","Harsh","Asha","Vinod"};
		int p[]={100,50,205,30,5};
	
		int min=p[1];

		for(int i=0;i<5;i++)
		{
			if(p[i]<min)
			{
				min=p[i];
			}
		}

		for(int i=0;i<5;i++)
		{
			if(min==p[i])
			{
				System.out.println(c[i]);
			}
		}

		System.out.println(min);
	}
}