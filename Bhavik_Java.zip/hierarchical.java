class  A
{
    public static void display()
    {
        System.out.println("This is class A");
    }
}

class B extends A
{
    public static void displayb()
    {
        System.out.println("This is class B");
    }
}

class C extends A
{
    public static void displayc()
    {
        System.out.println("This is class C");
    }
}



public class hierarchical
{
    public static void main(String args[])
    {
        B objb=new B();
        objb.display();
        objb.displayb();
        C obj=new C();
        obj.displayc();
    }
}
