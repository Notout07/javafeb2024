public class Example
{
    public static void main(String args[])
    {
        pack1.X obj1=new pack1.X();
        obj1.display1();
        pack1.Y obj2=new pack1.Y();
        obj2.display2();
        pack1.Z obj3=new pack1.Z();
        obj3.display3();
        pack2.P obj4=new pack2.P();
        obj4.display4();
        pack2.Q obj5=new pack2.Q();
        obj5.display5();
    }
}
