class A
{
    public void show()
    {
        System.out.println("This is class A method");
    }
}

class B extends A
{
    public void show()
    {
        System.out.println("This is class B method");
    }
    public void print()
    {
        super.show();
    }
}

public class vehicle
{
    public static void main(String[] args)
    {
        B v=new B();
        v.print();
        v.show();
    }
}
