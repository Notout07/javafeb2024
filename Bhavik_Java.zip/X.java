package pack1;

public class X
{
    public void display1()
    {
        System.out.println("This is X");
    }
}