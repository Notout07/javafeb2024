class  A
{
    static void display()
    {
        System.out.println("This is class A");
    }
}

class B extends A
{
    static void display1()
    {
        System.out.println("This is class B");
    }
}

class C extends B
{
    static void display2()
    {
        System.out.println("This is class C");
    }
}
public class multilevelinherit {
    public static void main(String args[])
    {
        C obj = new C();
        obj.display();
        obj.display1();
        obj.display2();
    }
}
