import pack4.mac;
public class dynamic {
    public static void main(String args[])
    {
        mac v=new mac();
        v.findmax();
    }


}
