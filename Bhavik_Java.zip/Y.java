package pack1;
public class Y extends X
{
    public void display2()
    {
        System.out.println("This is Y");
    }
}