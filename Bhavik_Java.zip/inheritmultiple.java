interface A
{
    void display1();
}

interface B
{
    void display2();
}

interface C extends A,B
{
    void display3();
}

class D implements C
{
    public void display1()
    {
        System.out.println("Interface A");
    }
    public void display2()
    {
        System.out.println("Interface B");
    }
    public void display3()
    {
        System.out.println("Interface C");
    }
}

public class inheritmultiple
{
    public static void main(String[] args)
    {
        D V=new D();
        V.display1();
        V.display2();
        V.display3();
    }
}
