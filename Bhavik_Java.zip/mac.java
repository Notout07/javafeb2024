package pack4;

public class mac
{
    public void findmax()
    {
        int a=5, b=6, c=8, max;
        if(a>b)
        {
            if(a>c)
            System.out.println("Maximum value is "+a);
        }
        else
        {
            if(b>c)
            {
            System.out.println("Maximum value is "+b);
            }
            else
            {
                System.out.println("Maximum value is "+c);
            }
        }
    }
    
}