package pack1;
public class Z
{
    public void display3()
    {
        System.out.println("This is Z");
    }
}