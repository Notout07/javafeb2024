package pack2;

public class Q
{
    public void display5()
    {
        
        System.out.println("This is Q");
    }
    
}
