class A
{
    public void show()
    {
        System.out.println("This is class A");
    }
}

interface B
{
    public void display();
}
interface C
{
    public void display1();
}

class D extends A implements B,C
{
    public void display()
    {
        System.out.println("This is class B");
    }
    public void display1()
    {
        System.out.println("This is class C");
    }
    public void display2()
    {
        System.out.println("This is class D");
    }
}
public class hybrid
{
    public static void main(String[] args)
    {
        D n=new D();
        n.show();
        n.display();
        n.display1();
        n.display2();
    }
}
