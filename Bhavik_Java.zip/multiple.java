interface A
{
    public void display();
}

interface B
{
    public void display1();
}

interface C extends A,B
{
    public void display2();
}

class D implements C
{
    public void display()
    {
        System.out.println(" This is class A");
    }

    public void display1()
    {
        System.out.println(" This is class B");
    }

    public void display2()
    {
        System.out.println(" This is class C");
    }

    public void display3()
    {
        System.out.println(" This is class D");
    }
}

public class multiple
{
    public static void main(String args[])
    {
        D f=new D();
        f.display();
        f.display1();
        f.display2();
        f.display3();
    }
}
