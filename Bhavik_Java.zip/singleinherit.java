/**
 * singleinherit
 */
class  A
{
    static void display()
    {
        System.out.println("This is class A");
    }
}

class B extends A
{
    static void display1()
    {
        System.out.println("This is class B");
    }
}

class singleinherit
{
    public static void main(String args[])
    {
        B obj=new B();
        obj.display();
        obj.display1();
    }
}
