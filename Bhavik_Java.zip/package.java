package p;
public class pkg1
{
    static public void display()
    {
        System.out.println("This is test class");
    }

}


