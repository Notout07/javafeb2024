package p;
public class pkg1
{
    public void display()
    {
        System.out.println("This is test class");
    }

}
