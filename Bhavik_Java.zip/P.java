package pack2;
import pack1.X;
public class P extends X
{
    public void display4()
    {
        System.out.println("This is P");
    }
}
