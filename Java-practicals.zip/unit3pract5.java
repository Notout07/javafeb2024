public class unit3pract5 {
    public static void main(String args[])

    {
         int a[]=new int[args.length];
         try
         {
            for (int i=0;i<args.length;i++)
             {
            a[i]=Integer.parseInt(args[i]);
            }
            for(int i=0;i<args.length;i++)
            {
                for(int j=i+1;j<args.length;j++)
                {
                    if(a[i]>a[j])
                    {
                        int temp=a[i];
                        a[i]=a[j];
                        a[j]=temp;
                    }
                    

                }
            }]
            System.out.println("lowest Number="+a[0]);
            System.out.println("Second lowest Number="+a[1]);


        }
     catch(ArithmeticException e)
    {
        System.out.println("Arithmatic Exception occur");    
    }
    catch(ArrayIndexOutOfBoundsException e)
    {
        System.out.println("Array Index OutOf BoundException occur");    
    }
    catch(Exception e)
    {
        System.out.println(e.getMessage());
    }

    }
    
}
