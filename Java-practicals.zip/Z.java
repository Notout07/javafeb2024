
package pack1;

public class Z {
    public void display()
    {
    System.out.println("this is display method of Z class");
    }
    
}
