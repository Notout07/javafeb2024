
package pack2;
import pack1.*;
public class Q {
    public void display()
    {
    System.out.println("this is display method of Q class");
    }
   
    
}
