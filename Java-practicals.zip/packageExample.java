import pack1.*;
import pack2.*;
class packageExample
{
    public static void main(String args[])
    {
        pack1.X obj1=new pack1.X();
        obj1.display();
        pack1.Y obj2=new pack1.Y();
        obj2.display();
    }
}