import p.*;

public class importpkg {
    public static void main(String args[])
    {
        pkg1 obj=new pkg1();
        obj.display();
    }

}
