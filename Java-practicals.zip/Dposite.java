class Dposite
{
    double deposite=5000,intrest=0,total=0;
    static void interest()
    {
    intrest=deposite * 65/100;
    total=interest*60;

    }
    public static void main(String args[]){
        interest();
        System.out.println("deposite ="+ deposite);
        System.out.println("Interest = "+ Interest );
        System.out.println("deposite = "+ total);
    }

}