
package pack1;

public class X {
    public void display()
    {
    System.out.println("this is display method of X class");
    }
    
}
