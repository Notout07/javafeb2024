package pack1;

public class Y extends X {
    public void display()
    {
    System.out.println("this is display method of Y class");
    }
    
}
