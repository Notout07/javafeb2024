class classA{
    public static void show(){
        System.out.println("this is class A");
    }
}
interface  Interfaceb
{
    public static void display1();
}
interface  Interfacec
{
    public static void display2();
}
class classD extends classA implements Interfaceb,Interfacec
{
    public static void display1()
    {
        System.out.println("This is interfaceb ");
    }
     public static void display2()
    {
        System.out.println("This is interfacec ");

    }
     public static void display3()
    {
        System.out.println("This is classD ");
    }
}
public class hybrid {
    
    public static void main(String args[])
    {
        classD obj=new classD();
        obj.show();
        obj.display1();
        obj.display2();
        obj.display3();
    }
}
