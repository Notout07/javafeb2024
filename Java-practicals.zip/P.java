
package pack2;
import pack1.*;
public class P extends X {
    public void display()
    {
    System.out.println("this is display method of P class");
    }
    
}
