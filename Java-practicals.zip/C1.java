package p1;
public  class C1
{
    public void printc1()
    {
        System.out.println("package p1 and class c1");
    }
}