public class Test{
  public static void main (String args[])
  {
  /*EMI=amount *rate /(100 * 60)
   price=200;
   tax=2;
   quantity=5;*/
   double total-price;
   
   System.out.println("1.Seat cover");
   System.out.println("2.steering wheel");
   switch(Integer.parseInt(args[0]))
   {
      case 1:
         total_price=200*args[1] + (2*200/100);
       break;
        case 2:
         total_price=300*args[1] + (3*300/100);
                break;
      default:System.out.println("invalid choice");
   }
   }
}
