/** write a java program to display power of 2 up to 10 */
class power{
    public static void main(String args[])
    {
        int a=1;
        for (int i=1;i<=10;i++)
        {
         a=a<<1;
            System.out.println(a);

        }
    }
}