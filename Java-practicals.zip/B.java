package pack2;
import pack1.*;
public class B {
    public static void main(String arg[])
    {
      A obj=new A();
      obj.printA();
      System.out.println("Instance variable ="+obj.a);
    }
}
