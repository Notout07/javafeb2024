import p1.C1;
public class default1 {
    public static void main(String args[])
    {
        C1 obj1=new C1();
        obj1.printc1();
    }
    
}
