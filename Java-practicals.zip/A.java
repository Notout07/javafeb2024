package pack1;

public class A {
    public int a=5;
    public void printA()
    {
        System.out.println("package pack1,class A and method printA");
    }
}
